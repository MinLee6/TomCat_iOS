//
//  AppDelegate.h
//  tom猫1
//
//  Created by limin on 14/11/10.
//  Copyright (c) 2014年 www.limin.com. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

